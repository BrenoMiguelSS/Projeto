#!/bin/bash

# Criação de diretórios
mkdir -p project/backend
mkdir -p project/frontend
mkdir -p project/mobile

# Setup do Backend
cd project/backend

# Inicializar projeto Node.js
npm init -y

# Instalar dependências
npm install express mongoose body-parser cors axios

# Criar arquivo server.js
cat <<EOT > server.js
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const axios = require('axios');  // Adiciona axios para requisições HTTP

const app = express();
const port = 5000;

app.use(bodyParser.json());
app.use(cors());

mongoose.connect('mongodb://localhost:27017/myapp', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => {
    console.log('Connected to MongoDB');
});

const itemSchema = new mongoose.Schema({
    location: {
        latitude: Number,
        longitude: Number
    },
    acceleration: {
        x: Number,
        y: Number,
        z: Number,
        timestamp: Number
    }
});

const Item = mongoose.model('Item', itemSchema);

app.post('/items', (req, res) => {
    const newItem = new Item(req.body);
    newItem.save((err, item) => {
        if (err) return res.status(500).send(err);
        res.status(201).send(item);
    });
});

app.get('/items', (req, res) => {
    Item.find((err, items) => {
        if (err) return res.status(500).send(err);
        res.status(200).send(items);
    });
});

app.put('/items/:id', (req, res) => {
    Item.findByIdAndUpdate(req.params.id, req.body, { new: true }, (err, item) => {
        if (err) return res.status(500).send(err);
        res.status(200).send(item);
    });
});

app.delete('/items/:id', (req, res) => {
    Item.findByIdAndDelete(req.params.id, (err) => {
        if (err) return res.status(500).send(err);
        res.status(204).send();
    });
});

app.listen(port, () => {
    console.log(\`Server running on port \${port}\`);
});
EOT

# Setup do Frontend
cd ../..
npx create-react-app frontend

# Substituir arquivos no frontend
cd project/frontend/src
rm -f App.js index.js
cat <<EOT > App.js
import React from 'react';
import ItemList from './components/ItemList';

function App() {
    return (
        <div className="App">
            <h1>Item Management</h1>
            <ItemList />
        </div>
    );
}

export default App;
EOT

cat <<EOT > index.js
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';

ReactDOM.render(
    <React.StrictMode>
        <App />
    </React.StrictMode>,
    document.getElementById('root')
);
EOT

mkdir -p components
cd components

cat <<EOT > ItemForm.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ItemForm = ({ selectedItem, refreshItems }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');

    useEffect(() => {
        if (selectedItem) {
            setName(selectedItem.name);
            setDescription(selectedItem.description);
        }
    }, [selectedItem]);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (selectedItem) {
            axios.put(\`http://localhost:5000/items/\${selectedItem._id}\`, { name, description })
                .then(refreshItems)
                .catch(console.error);
        } else {
            axios.post('http://localhost:5000/items', { name, description })
                .then(refreshItems)
                .catch(console.error);
        }
        setName('');
        setDescription('');
    };

    return (
        <form onSubmit={handleSubmit}>
            <input 
                type="text" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                placeholder="Name" 
                required 
            />
            <input 
                type="text" 
                value={description} 
                onChange={(e) => setDescription(e.target.value)} 
                placeholder="Description" 
                required 
            />
            <button type="submit">Save</button>
        </form>
    );
};

export default ItemForm;
EOT

cat <<EOT > ItemList.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Item from './Item';
import ItemForm from './ItemForm';

const ItemList = () => {
    const [items, setItems] = useState([]);
    const [selectedItem, setSelectedItem] = useState(null);

    const fetchItems = () => {
        axios.get('http://localhost:5000/items')
            .then((response) => setItems(response.data))
            .catch(console.error);
    };

    useEffect(() => {
        fetchItems();
    }, []);

    const handleDelete = (id) => {
        axios.delete(\`http://localhost:5000
