import React from 'react';

const Item = ({ item, onDelete, onEdit }) => {
    return (
        <li>
            <strong>{item.name}</strong>: {item.description}
            <button onClick={onEdit}>Edit</button>
            <button onClick={onDelete}>Delete</button>
        </li>
    );
};

export default Item;
