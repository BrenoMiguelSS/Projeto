import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ItemForm = ({ selectedItem, refreshItems }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');

    useEffect(() => {
        if (selectedItem) {
            setName(selectedItem.name);
            setDescription(selectedItem.description);
        }
    }, [selectedItem]);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (selectedItem) {
            axios.put(`http://localhost:5000/items/${selectedItem._id}`, { name, description })
                .then(refreshItems)
                .catch(console.error);
        } else {
            axios.post('http://localhost:5000/items', { name, description })
                .then(refreshItems)
                .catch(console.error);
        }
        setName('');
        setDescription('');
    };

    return (
        <form onSubmit={handleSubmit}>
            <input 
                type="text" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                placeholder="Name" 
                required 
            />
            <input 
                type="text" 
                value={description} 
                onChange={(e) => setDescription(e.target.value)} 
                placeholder="Description" 
                required 
            />
            <button type="submit">Save</button>
        </form>
    );
};

export default ItemForm;
