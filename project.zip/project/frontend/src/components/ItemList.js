import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Item from './Item';
import ItemForm from './ItemForm';

const ItemList = () => {
    const [items, setItems] = useState([]);
    const [selectedItem, setSelectedItem] = useState(null);

    const fetchItems = () => {
        axios.get('http://localhost:5000/items')
            .then((response) => setItems(response.data))
            .catch(console.error);
    };

    useEffect(() => {
        fetchItems();
    }, []);

    const handleDelete = (id) => {
        axios.delete(`http://localhost:5000/items/${id}`)
            .then(fetchItems)
            .catch(console.error);
    };

    return (
        <div>
            <ItemForm selectedItem={selectedItem} refreshItems={fetchItems} />
            <ul>
                {items.map((item) => (
                    <Item 
                        key={item._id} 
                        item={item} 
                        onDelete={() => handleDelete(item._id)} 
                        onEdit={() => setSelectedItem(item)} 
                    />
                ))}
            </ul>
        </div>
    );
};

export default ItemList;
