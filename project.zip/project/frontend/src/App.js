import React from 'react';
import ItemList from './components/ItemList';

function App() {
    return (
        <div className="App">
            <h1>Item Management</h1>
            <ItemList />
        </div>
    );
}

export default App;
