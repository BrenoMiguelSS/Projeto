import React, { useEffect, useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import Geolocation from '@react-native-community/geolocation';
import { accelerometer, setUpdateIntervalForType, SensorTypes } from 'react-native-sensors';
import axios from 'axios';

const App = () => {
    const [location, setLocation] = useState(null);
    const [acceleration, setAcceleration] = useState(null);

    useEffect(() => {
        setUpdateIntervalForType(SensorTypes.accelerometer, 1000);

        const accelerometerSubscription = accelerometer.subscribe(({ x, y, z, timestamp }) => {
            setAcceleration({ x, y, z, timestamp });
        });

        return () => {
            accelerometerSubscription.unsubscribe();
        };
    }, []);

    const getLocation = () => {
        Geolocation.getCurrentPosition(
            position => {
                const { latitude, longitude } = position.coords;
                setLocation({ latitude, longitude });
            },
            error => console.error(error),
            { enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
        );
    };

    const sendDataToBackend = () => {
        const data = {
            location,
            acceleration
        };

        axios.post('http://localhost:5000/items', data)
            .then(response => console.log('Data sent to backend:', response.data))
            .catch(error => console.error('Error sending data:', error));
    };

    return (
        <View style={styles.container}>
            <Text>Sensor Data</Text>
            <Button title="Get Location" onPress={getLocation} />
            {location && (
                <Text>Location: {`Latitude: ${location.latitude}, Longitude: ${location.longitude}`}</Text>
            )}
            {acceleration && (
                <Text>Acceleration: {`x: ${acceleration.x.toFixed(2)}, y: ${acceleration.y.toFixed(2)}, z: ${acceleration.z.toFixed(2)}`}</Text>
            )}
            <Button title="Send Data to Backend" onPress={sendDataToBackend} />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 16,
    },
});

export default App;
