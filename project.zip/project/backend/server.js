const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const axios = require('axios');  // Adiciona axios para requisições HTTP

const app = express();
const port = 5000;

app.use(bodyParser.json());
app.use(cors());

mongoose.connect('mongodb://localhost:27017/myapp', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => {
    console.log('Connected to MongoDB');
});

const itemSchema = new mongoose.Schema({
    location: {
        latitude: Number,
        longitude: Number
    },
    acceleration: {
        x: Number,
        y: Number,
        z: Number,
        timestamp: Number
    }
});

const Item = mongoose.model('Item', itemSchema);

app.post('/items', (req, res) => {
    const newItem = new Item(req.body);
    newItem.save((err, item) => {
        if (err) return res.status(500).send(err);
        res.status(201).send(item);
    });
});

app.get('/items', (req, res) => {
    Item.find((err, items) => {
        if (err) return res.status(500).send(err);
        res.status(200).send(items);
    });
});

app.put('/items/:id', (req, res) => {
    Item.findByIdAndUpdate(req.params.id, req.body, { new: true }, (err, item) => {
        if (err) return res.status(500).send(err);
        res.status(200).send(item);
    });
});

app.delete('/items/:id', (req, res) => {
    Item.findByIdAndDelete(req.params.id, (err) => {
        if (err) return res.status(500).send(err);
        res.status(204).send();
    });
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
